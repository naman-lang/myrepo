export class LoginData {
  username: string | any;
  password: string | any;
}
