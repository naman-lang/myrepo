export class ResetData {
  username: string | any;
  newPassword: string | any;
  secQuestion: string | any;
  secAnswer: string | any;
}
