export class BookingData {
    seatNumbers:string|any;
    numberOfTickets:number|any;
    movieName:string|any;
    theaterName:string|any;
    userId:string|any;
}
