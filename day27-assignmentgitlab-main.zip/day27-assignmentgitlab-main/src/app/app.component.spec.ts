// import { TestBed } from '@angular/core/testing';
// import { AppComponent } from './app.component';
// import { StudentsComponent } from './students/students.component';

// describe('AppComponent', () => {
//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       declarations: [AppComponent, StudentsComponent],
//     }).compileComponents();
//   });
// });
