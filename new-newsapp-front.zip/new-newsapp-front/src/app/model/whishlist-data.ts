export class WhishlistData {
    id:number|any;
    name: String | any ;
	author : String | any;
    title  :  String | any;
	description :  String | any;
	category :  String | any;
	publishedAt: String | any;
	url : String | any;
    urlToImage : String | any;
    userId:string|any;
}
