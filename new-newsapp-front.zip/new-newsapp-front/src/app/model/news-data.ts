import { Articles } from "./Articles";

export class NewsData {
   totalResults : String| any ;
	articles : Articles[] | any;
	
}
