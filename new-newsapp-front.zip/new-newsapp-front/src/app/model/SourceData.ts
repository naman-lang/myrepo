export class SourceData{
    id: string | any;
   name: string | any ;
}