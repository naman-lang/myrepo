import{SourceData} from './SourceData'
export class Articles{
  source : SourceData| any;
	author : string | any;
  title  :  string | any;
	description :  string | any;
	content :  string| any;
	category :  string | any;
	publishedAt: string | any;
	url : string | any;
  urlToImage : string | any;
}