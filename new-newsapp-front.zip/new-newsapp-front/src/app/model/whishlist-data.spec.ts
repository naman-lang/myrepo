import { WhishlistData } from './whishlist-data';

describe('WhishlistData', () => {
  it('should create an instance', () => {
    expect(new WhishlistData()).toBeTruthy();
  });
});
