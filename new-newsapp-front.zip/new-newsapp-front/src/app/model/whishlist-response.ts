import { WhishlistData } from "./whishlist-data";

export class WhishlistResponse {
    headers: any;
    body: WhishlistData[]|any;
    statusCode: string|any;
    statusCodeValue: number|any;
}
