import { StocksData } from './stocks-data';

describe('StocksData', () => {
  it('should create an instance', () => {
    expect(new StocksData()).toBeTruthy();
  });
});
