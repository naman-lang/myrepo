import { StocksResponse } from './stocks-response';

describe('StocksResponse', () => {
  it('should create an instance', () => {
    expect(new StocksResponse()).toBeTruthy();
  });
});
