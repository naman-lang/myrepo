import { WhishlistResponse } from './whishlist-response';

describe('WhishlistResponse', () => {
  it('should create an instance', () => {
    expect(new WhishlistResponse()).toBeTruthy();
  });
});
