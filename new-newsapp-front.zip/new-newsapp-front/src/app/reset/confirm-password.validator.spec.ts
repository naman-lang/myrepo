import { ConfirmPasswordValidator } from './confirm-password.validator';

describe('ConfirmPasswordValidator', () => {
  it('should create an instance', () => {
    expect(new ConfirmPasswordValidator()).toBeTruthy();
  });
});
